package com.tomekl007.cassandra.model

case class KV(key: String, value: Int)
