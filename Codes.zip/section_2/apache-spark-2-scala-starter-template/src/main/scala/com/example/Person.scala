package com.example

case class Person(name:String, age:Long)